#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include "pantalla.h"


int main(){

  pantalla();
  printf("\n");
  menu();

  return 0;
}
