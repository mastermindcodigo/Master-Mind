// gestion del juego

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int jugar_partida(int modo){

  if(modo==0){ //MODO NORMAL DE JUEGO

  printf("Se va a jugar una partida");
  return 0;
  }
  
  else{
    printf("Se va a jugar una partida de prueba");
  }
}

int establecer_nivel(){}

int listar_historial(){}

